import Header from './components/header/header'
import Background from './components/hoc/Background'
import RandomMovie from './components/random-movie/RandomMovie'

function App() {
  return (
    <div>
      <Header/>
      <Background>
        <RandomMovie/>
        
      </Background>
    </div>
  );
}

export default App;
