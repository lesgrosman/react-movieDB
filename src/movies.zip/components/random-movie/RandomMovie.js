import React from 'react'
import classes from './RandomMovie.module.css'
import poster from '../../posters/pulp_fiction.jpg'

function RandomMovie() {
    return (
        <div className={classes.Layout}>
            <div className={classes.RandomMovie}>
                <img src={poster} alt="imag"/>
                <div className={classes.RandomMovieContent}>
                    <h3>Pulp Fiction</h3>
                    <span>ReactJS is a very popular framework for creating modern web applications for the browser.</span>
                    <ul>
                        <li>
                            <strong>Director</strong>: Quentin Tarantino
                        </li>
                        <li>
                            <strong>Year</strong>: 1994
                        </li>
                    </ul>
                </div>
            </div>
            <button>Randomize movie</button>
        </div>
    )
}

export default RandomMovie